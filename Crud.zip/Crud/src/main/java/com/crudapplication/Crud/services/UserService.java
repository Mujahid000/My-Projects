package com.crudapplication.Crud.services;

import java.util.List;

import com.crudapplication.Crud.model.User;

public interface UserService {

	public User addUser(User user);
	
	public List<User> getUsers();
	
	public User getUser(long userId);
	
	public User updateUser(User user);
	
	public User deleteUser(long userId);
}
