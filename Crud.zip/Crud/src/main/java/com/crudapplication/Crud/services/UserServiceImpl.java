package com.crudapplication.Crud.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crudapplication.Crud.Dao.UserDao;
import com.crudapplication.Crud.model.User;

@Service											// @Service annotation is use to tell the spring boot that this is the service.
public class UserServiceImpl implements UserService {

	@Autowired						// Spring boot internally makes Interface Objects with the help of @Autowired annotation.
	private UserDao userdao;
	
	@Override
	public User addUser(User user) {
		userdao.save(user);
		return user;
	}

	@Override
	public List<User> getUsers() {
		return userdao.findAll();
	}

	@Override
	public User getUser(long userId) {
		return userdao.findById(userId).get();
	}

	@Override
	public User updateUser(User user) {
		userdao.save(user);
		return user;
	}

	@Override
	public User deleteUser(long userId) {
		User user = userdao.findById(userId).get();
		userdao.delete(user);
		return user;
	}

}
