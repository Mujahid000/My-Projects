package com.crudapplication.Crud.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crudapplication.Crud.model.User;

public interface UserDao extends JpaRepository<User, Long> {        // JpaRepository take two things in it: 1st it takes Model name & 2nd it takes datatype of primary key. 

}
